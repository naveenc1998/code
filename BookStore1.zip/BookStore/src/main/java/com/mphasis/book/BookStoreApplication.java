package com.mphasis.book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mphasis.book.domain.Book;
import com.mphasis.book.repository.BookStoreRepository;

@SpringBootApplication
public class BookStoreApplication  implements CommandLineRunner {
    
	@Autowired
	@Qualifier("bookStoreRepository")
	private BookStoreRepository bookStoreRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(BookStoreApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		bookStoreRepository.save(new Book(".Net","publisher1",78,250,2018));
		bookStoreRepository.save(new Book("Java","publisher2",45,350,2020));
		bookStoreRepository.save(new Book("Angular","publisher3",56,150,2013));
		bookStoreRepository.save(new Book("Spring","publisher4",45,250,2019));
	}

	public BookStoreRepository getBookStoreRepository() {
		return bookStoreRepository;
	}

	public void setBookStoreRepository(BookStoreRepository bookStoreRepository) {
		this.bookStoreRepository = bookStoreRepository;
	}

	
	
	
	
}
