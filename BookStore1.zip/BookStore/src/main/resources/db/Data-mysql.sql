
INSERT INTO mphasisdb.book(bookTitle, bookPublisher,bookIsbn, bookPages, bookYear) VALUES('.Net',"publisher1",78,250,2018); 

INSERT INTO mphasisdb.book(bookTitle, bookPublisher,bookIsbn, bookPages, bookYear) VALUES('Java',"publisher2",45,350,2020);  

INSERT INTO mphasisdb.book(bookTitle, bookPublisher,bookIsbn, bookPages, bookYear) VALUES('Angular',"publisher3",56,150,2013);  

INSERT INTO mphasisdb.book(bookTitle, bookPublisher,bookIsbn, bookPages, bookYear) VALUES('Spring',"publisher4",45,250,2019);

 