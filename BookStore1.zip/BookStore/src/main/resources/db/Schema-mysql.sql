USE mphasisdb;  

DROP TABLE IF EXISTS Book; 

CREATE TABLE mphasisdb.book ( 

id INT PRIMARY KEY  AUTO_INCREMENT, 

bookTitle VARCHAR(255), 
 
bookPublisher VARCHAR(255),

bookIsbn INT,

bookNumberOfPages INT,

bookYear INT

);